#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using System.Windows.Forms;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    public enum MAType { EMA, HMA, SMA, TMA, VMA, WMA, DEMA, TEMA, VWMA, ZLEMA, LinReg }
    public enum ColorStyle { Transparent, RegionColors, CustomColors, PlotColors }

    public class ArrowLineData
    {
        public double Price { get; set; }
        public int StartBar { get; set; }
        public bool IsUpArrow { get; set; }
        public string Tag { get; set; }
        public bool IsActive { get; set; }
    }

    [Gui.CategoryOrder("Parameters", 1000000)]
    [Gui.CategoryOrder("EMAs", 1000001)]
    [Gui.CategoryOrder("RSI", 1000002)]
    [Gui.CategoryOrder("Options", 1000003)]
    [Gui.CategoryOrder("Custom Colors", 1000004)]
    public class MonarcaBand : Indicator
    {
        #region Globals
        private MAType triggerMAType = MAType.SMA;
        private int triggerPeriod = 12;
        private MAType averageMAType = MAType.SMA;
        private int averagePeriod = 12;
        private Brush triggerRisingColor = Brushes.Lime;
        private Brush triggerFallingColor = Brushes.Yellow;
        private Brush averageRisingColor = Brushes.Cyan;
        private Brush averageFallingColor = Brushes.Red;
        private bool drawArrows = true;
        private int arrowOffset = 10;
        private Brush arrowUpColor = Brushes.Cyan;
        private Brush arrowDownColor = Brushes.Magenta;
        private bool ArrowDrawn = false;
        private bool colorRegion = true;
        private ColorStyle colorLines = ColorStyle.RegionColors;
        private int regionOpacity = 30;
        private Brush regionUpColor = Brushes.PaleTurquoise;
        private Brush regionDownColor = Brushes.Pink;
        private int StartIndex = 1;
        private int PriorIndex = 0;
        private bool soundAlert = false;
        private string soundFile = "Alert4.wav";
        private bool SoundPlayed = false;
        private bool SoundBandPlayed = false;
        private Series<bool> upTrend = null;
        private int MinBarsNeeded = 1;
        private double ArrowTickOffset = 0;
        private List<ArrowLineData> extendedLines = new List<ArrowLineData>();

        // EMAs Variables
        private int emaShortLength = 200;
        private int emaLongLength = 800;
        private bool showEMAs = true;
        private bool showEMACrosses = true;
        private Brush emaShortColor = Brushes.Blue;
        private Brush emaLongColor = Brushes.Green;
        private Brush emaCrossUpColor = Brushes.Green;
        private Brush emaCrossDownColor = Brushes.Red;
        private EMA emaShort;
        private EMA emaLong;

        // RSI Variables
        private int rsiLength = 14;
        private int rsiOverbought = 70;
        private int rsiOversold = 30;
        private bool showRsiSignals = true;
        private Brush rsiOversoldColor = Brushes.Green;
        private Brush rsiOverboughtColor = Brushes.Red;
        private RSI rsi;
        #endregion

        private void Initialize()
        {
            AddPlot(new Stroke(Brushes.Green, 2), PlotStyle.Line, "Trigger");
            AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Line, "Average");
            AddPlot(new Stroke(Brushes.Blue, 2), PlotStyle.Line, "EMA Short");
            AddPlot(new Stroke(Brushes.Green, 2), PlotStyle.Line, "EMA Long");
            IsOverlay = true;
            ArePlotsConfigurable = true;
            PaintPriceMarkers = false;
            Calculate = Calculate.OnEachTick;
            upTrend = new Series<bool>(this);
        }

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name = "MonarcaBand";
                    Description = "Trigger Lines";
                    DrawDottedLine = true;
                    DottedLinePipsRange = 2000;
                    SoundAlertBand = false;
                    SoundFileBand = "Alert2.wav";
                    Initialize();
                    break;
                case State.DataLoaded:
                    emaShort = EMA(Close, emaShortLength);
                    emaLong = EMA(Close, emaLongLength);
                    rsi = RSI(Close, rsiLength, 3);
                    OnStartUp();
                    break;
            }
        }

        public override string DisplayName
        {
            get { return string.Format("{0}({1},{2},{3},{4})", Name, TriggerMAType, TriggerPeriod, AverageMAType, AveragePeriod); }
        }

        private void OnStartUp()
        {
            MinBarsNeeded = Math.Max(TriggerPeriod, AveragePeriod) + 1;
            MinBarsNeeded = Math.Max(MinBarsNeeded, Math.Max(emaShortLength, emaLongLength));
            MinBarsNeeded = Math.Max(MinBarsNeeded, rsiLength);
            ArrowTickOffset = ArrowOffset * TickSize;
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < MinBarsNeeded) return;

            if (IsFirstTickOfBar)
            {
                for (int i = extendedLines.Count - 1; i >= 0; i--)
                {
                    var line = extendedLines[i];
                    if (line.IsActive)
                    {
                        if ((line.IsUpArrow && Low[1] <= line.Price) || (!line.IsUpArrow && High[1] >= line.Price))
                        {
                            line.IsActive = false;
                        }
                        else
                        {
                            Draw.Line(this, line.Tag, false, CurrentBar - line.StartBar, line.Price, 0, line.Price, line.IsUpArrow ? ArrowUpColor : ArrowDownColor, DashStyleHelper.Dot, 2);
                        }
                    }
                }
            }

            if ((Calculate == Calculate.OnBarClose) || IsFirstTickOfBar)
            {
                ArrowDrawn = false;
                SoundPlayed = false;
                SoundBandPlayed = false;
            }

            // Calculate Trigger
            switch (TriggerMAType)
            {
                case MAType.EMA: Trigger[0] = EMA(Input, TriggerPeriod)[0]; break;
                case MAType.HMA: Trigger[0] = HMA(Input, TriggerPeriod)[0]; break;
                case MAType.SMA: Trigger[0] = SMA(Input, TriggerPeriod)[0]; break;
                case MAType.TMA: Trigger[0] = TMA(Input, TriggerPeriod)[0]; break;
                case MAType.WMA: Trigger[0] = WMA(Input, TriggerPeriod)[0]; break;
                case MAType.DEMA: Trigger[0] = DEMA(Input, TriggerPeriod)[0]; break;
                case MAType.TEMA: Trigger[0] = TEMA(Input, TriggerPeriod)[0]; break;
                case MAType.VWMA: Trigger[0] = VWMA(Input, TriggerPeriod)[0]; break;
                case MAType.ZLEMA: Trigger[0] = ZLEMA(Input, TriggerPeriod)[0]; break;
                case MAType.LinReg: Trigger[0] = LinReg(Input, TriggerPeriod)[0]; break;
            }

            // Calculate Average
            switch (AverageMAType)
            {
                case MAType.EMA: Average[0] = EMA(Trigger, AveragePeriod)[0]; break;
                case MAType.HMA: Average[0] = HMA(Trigger, AveragePeriod)[0]; break;
                case MAType.SMA: Average[0] = SMA(Trigger, AveragePeriod)[0]; break;
                case MAType.TMA: Average[0] = TMA(Trigger, AveragePeriod)[0]; break;
                case MAType.WMA: Average[0] = WMA(Trigger, AveragePeriod)[0]; break;
                case MAType.DEMA: Average[0] = DEMA(Trigger, AveragePeriod)[0]; break;
                case MAType.TEMA: Average[0] = TEMA(Trigger, AveragePeriod)[0]; break;
                case MAType.VWMA: Average[0] = VWMA(Trigger, AveragePeriod)[0]; break;
                case MAType.ZLEMA: Average[0] = ZLEMA(Trigger, AveragePeriod)[0]; break;
                case MAType.LinReg: Average[0] = LinReg(Trigger, AveragePeriod)[0]; break;
            }

            // Plot EMAs
            if (ShowEMAs)
            {
                EMAShort[0] = emaShort[0];
                EMALong[0] = emaLong[0];
                PlotBrushes[2][0] = EMAShortColor;
                PlotBrushes[3][0] = EMALongColor;
            }
            else
            {
                EMAShort[0] = 0;
                EMALong[0] = 0;
                PlotBrushes[2][0] = Brushes.Transparent;
                PlotBrushes[3][0] = Brushes.Transparent;
            }

            // EMA Crosses
            if (ShowEMACrosses && CurrentBar > 1)
            {
                if (CrossAbove(emaShort, emaLong, 1))
                {
                    Draw.ArrowUp(this, "EMACrossUp" + CurrentBar, true, 0, Low[0] - (5 * TickSize), EMACrossUpColor);
                }
                else if (CrossBelow(emaShort, emaLong, 1))
                {
                    Draw.ArrowDown(this, "EMACrossDown" + CurrentBar, true, 0, High[0] + (5 * TickSize), EMACrossDownColor);
                }
            }

            // RSI Signals
            if (ShowRsiSignals && CurrentBar > 1)
            {
                if (rsi[1] >= RsiOversold && rsi[0] < RsiOversold)
                {
                    Draw.Dot(this, "RSIOversold" + CurrentBar, true, 0, Low[0] - (3 * TickSize), RsiOversoldColor);
                }
                else if (rsi[1] <= RsiOverbought && rsi[0] > RsiOverbought)
                {
                    Draw.Dot(this, "RSIOverbought" + CurrentBar, true, 0, High[0] + (3 * TickSize), RsiOverboughtColor);
                }
            }

            if (CurrentBar < MinBarsNeeded) return;

            if (ColorLines == ColorStyle.Transparent)
            {
                PlotBrushes[0][-Displacement] = Brushes.Transparent;
                PlotBrushes[1][-Displacement] = Brushes.Transparent;
            }
            else if (ColorLines == ColorStyle.CustomColors)
            {
                PlotBrushes[0][0] = IsRising(Trigger) ? TriggerRisingColor : TriggerFallingColor;
                PlotBrushes[1][0] = IsRising(Average) ? AverageRisingColor : AverageFallingColor;
            }

            if (CrossAbove(Trigger, Average, 1))
            {
                double arrowBasePrice = Average[1] - ArrowTickOffset;
                if (DrawArrows)
                {
                    Draw.ArrowUp(this, "Arrow" + (CurrentBar - 1), true, 1, arrowBasePrice, ArrowUpColor);
                }
                if (SoundAlert && !SoundPlayed)
                {
                    PlaySound(SoundFile);
                    SoundPlayed = true;
                }
                if (DrawDottedLine)
                {
                    double pipsRange = DottedLinePipsRange * TickSize;
                    if (Math.Abs(Close[0] - arrowBasePrice) <= pipsRange)
                    {
                        extendedLines.Add(new ArrowLineData { Price = arrowBasePrice, StartBar = CurrentBar, IsUpArrow = true, Tag = "DottedLine" + CurrentBar, IsActive = true });
                    }
                }
            }
            else if (CrossBelow(Trigger, Average, 1))
            {
                double arrowBasePrice = Average[1] + ArrowTickOffset;
                if (DrawArrows)
                {
                    Draw.ArrowDown(this, "Arrow" + (CurrentBar - 1), true, 1, arrowBasePrice, ArrowDownColor);
                }
                if (SoundAlert && !SoundPlayed)
                {
                    PlaySound(SoundFile);
                    SoundPlayed = true;
                }
                if (DrawDottedLine)
                {
                    double pipsRange = DottedLinePipsRange * TickSize;
                    if (Math.Abs(Close[0] - arrowBasePrice) <= pipsRange)
                    {
                        extendedLines.Add(new ArrowLineData { Price = arrowBasePrice, StartBar = CurrentBar, IsUpArrow = false, Tag = "DottedLine" + CurrentBar, IsActive = true });
                    }
                }
            }

            if (Trigger[0] > Average[0])
            {
                if (ColorLines == ColorStyle.RegionColors)
                {
                    PlotBrushes[0][-Displacement] = upTrend[1] ? RegionUpColor : RegionDownColor;
                    PlotBrushes[1][-Displacement] = upTrend[1] ? RegionUpColor : RegionDownColor;
                }
                if (ColorRegion && RegionOpacity != 0)
                {
                    if (IsFirstTickOfBar) PriorIndex = StartIndex;
                    int CountBars = CurrentBar - PriorIndex + 1 - Displacement;
                    if (upTrend[1])
                    {
                        if (StartIndex == CurrentBar) RemoveDrawObject("Region" + CurrentBar);
                        if (CountBars <= CurrentBar) Draw.Region(this, "Region" + PriorIndex, CountBars, -Displacement, Trigger, Average, null, RegionUpColor, RegionOpacity);
                        StartIndex = PriorIndex;
                    }
                    else
                    {
                        if (CountBars <= CurrentBar && StartIndex == PriorIndex) Draw.Region(this, "Region" + PriorIndex, CountBars, 1 - Displacement, Trigger, Average, null, RegionDownColor, RegionOpacity);
                        Draw.Region(this, "Region" + CurrentBar, 1 - Displacement, -Displacement, Trigger, Average, null, RegionUpColor, RegionOpacity);
                        StartIndex = CurrentBar;
                    }
                }
                if (SoundAlertBand && !SoundBandPlayed && Close[0] > Average[0] && Close[0] < Trigger[0])
                {
                    PlaySound(SoundFileBand);
                    SoundBandPlayed = true;
                }
                upTrend[0] = true;
            }
            else if (Trigger[0] < Average[0])
            {
                if (ColorLines == ColorStyle.RegionColors)
                {
                    PlotBrushes[0][-Displacement] = upTrend[1] ? RegionUpColor : RegionDownColor;
                    PlotBrushes[1][-Displacement] = upTrend[1] ? RegionUpColor : RegionDownColor;
                }
                if (ColorRegion && RegionOpacity != 0)
                {
                    if (IsFirstTickOfBar) PriorIndex = StartIndex;
                    int CountBars = CurrentBar - PriorIndex + 1 - Displacement;
                    if (!upTrend[1])
                    {
                        if (StartIndex == CurrentBar) RemoveDrawObject("Region" + CurrentBar);
                        if (CountBars <= CurrentBar) Draw.Region(this, "Region" + PriorIndex, CurrentBar - PriorIndex + 1 - Displacement, -Displacement, Trigger, Average, null, RegionDownColor, RegionOpacity);
                        StartIndex = PriorIndex;
                    }
                    else
                    {
                        if (CountBars <= CurrentBar && StartIndex == PriorIndex) Draw.Region(this, "Region" + PriorIndex, CurrentBar - PriorIndex + 1 - Displacement, 1 - Displacement, Trigger, Average, null, RegionUpColor, RegionOpacity);
                        Draw.Region(this, "Region" + CurrentBar, 1 - Displacement, -Displacement, Trigger, Average, null, RegionDownColor, RegionOpacity);
                        StartIndex = CurrentBar;
                    }
                }
                if (SoundAlertBand && !SoundBandPlayed && Close[0] < Average[0] && Close[0] > Trigger[0])
                {
                    PlaySound(SoundFileBand);
                    SoundBandPlayed = true;
                }
                upTrend[0] = false;
            }
            else
            {
                if (ColorLines == ColorStyle.RegionColors)
                {
                    PlotBrushes[0][-Displacement] = upTrend[1] ? RegionUpColor : RegionDownColor;
                    PlotBrushes[1][-Displacement] = upTrend[1] ? RegionUpColor : RegionDownColor;
                }
                if (ColorRegion && RegionOpacity != 0)
                {
                    if (IsFirstTickOfBar) PriorIndex = StartIndex;
                    int CountBars = CurrentBar - PriorIndex + 1 - Displacement;
                    if (StartIndex == CurrentBar) RemoveDrawObject("Region" + CurrentBar);
                    if (CountBars <= CurrentBar) Draw.Region(this, "Region" + PriorIndex, CountBars, -Displacement, Trigger, Average, null, upTrend[1] ? RegionUpColor : RegionDownColor, RegionOpacity);
                    StartIndex = PriorIndex;
                }
                upTrend[0] = upTrend[1];
            }
        }

        #region Property Grid
        [Browsable(false)] [XmlIgnore()] public Series<double> Trigger { get { return Values[0]; } }
        [Browsable(false)] [XmlIgnore()] public Series<double> Average { get { return Values[1]; } }
        [Browsable(false)] [XmlIgnore()] public Series<double> EMAShort { get { return Values[2]; } }
        [Browsable(false)] [XmlIgnore()] public Series<double> EMALong { get { return Values[3]; } }
        [Browsable(false)] [XmlIgnore()] public Series<bool> UpTrend { get { return upTrend; } }

        // MonarcaBand Parameters
        [NinjaScriptProperty] [Display(Name = "TriggerMAType", GroupName = "Parameters", Order = 1)] public MAType TriggerMAType { get { return triggerMAType; } set { triggerMAType = value; } }
        [NinjaScriptProperty] [Display(Name = "TriggerPeriod", GroupName = "Parameters", Order = 2)] public int TriggerPeriod { get { return triggerPeriod; } set { triggerPeriod = Math.Max(1, value); } }
        [NinjaScriptProperty] [Display(Name = "AverageMAType", GroupName = "Parameters", Order = 3)] public MAType AverageMAType { get { return averageMAType; } set { averageMAType = value; } }
        [NinjaScriptProperty] [Display(Name = "AveragePeriod", GroupName = "Parameters", Order = 4)] public int AveragePeriod { get { return averagePeriod; } set { averagePeriod = Math.Max(1, value); } }

        // EMAs Parameters
        [NinjaScriptProperty] [Display(Name = "EMA Short Length", Description = "US30: 200, XAUUSD: 200", GroupName = "EMAs", Order = 1)] public int EMAShortLength { get { return emaShortLength; } set { emaShortLength = Math.Max(1, value); } }
        [NinjaScriptProperty] [Display(Name = "EMA Long Length", Description = "US30: 800, XAUUSD: 800", GroupName = "EMAs", Order = 2)] public int EMALongLength { get { return emaLongLength; } set { emaLongLength = Math.Max(1, value); } }
        [NinjaScriptProperty] [Display(Name = "Show EMAs", GroupName = "EMAs", Order = 3)] public bool ShowEMAs { get { return showEMAs; } set { showEMAs = value; } }
        [NinjaScriptProperty] [Display(Name = "Show EMA Crosses", GroupName = "EMAs", Order = 4)] public bool ShowEMACrosses { get { return showEMACrosses; } set { showEMACrosses = value; } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "EMA Short Color", GroupName = "EMAs", Order = 5)] public Brush EMAShortColor { get { return emaShortColor; } set { emaShortColor = value; } }
        [Browsable(false)] public string EMAShortColorSerialize { get { return Serialize.BrushToString(emaShortColor); } set { emaShortColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "EMA Long Color", GroupName = "EMAs", Order = 6)] public Brush EMALongColor { get { return emaLongColor; } set { emaLongColor = value; } }
        [Browsable(false)] public string EMALongColorSerialize { get { return Serialize.BrushToString(emaLongColor); } set { emaLongColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "EMA Cross Up Color", GroupName = "EMAs", Order = 7)] public Brush EMACrossUpColor { get { return emaCrossUpColor; } set { emaCrossUpColor = value; } }
        [Browsable(false)] public string EMACrossUpColorSerialize { get { return Serialize.BrushToString(emaCrossUpColor); } set { emaCrossUpColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "EMA Cross Down Color", GroupName = "EMAs", Order = 8)] public Brush EMACrossDownColor { get { return emaCrossDownColor; } set { emaCrossDownColor = value; } }
        [Browsable(false)] public string EMACrossDownColorSerialize { get { return Serialize.BrushToString(emaCrossDownColor); } set { emaCrossDownColor = Serialize.StringToBrush(value); } }

        // RSI Parameters
        [NinjaScriptProperty] [Display(Name = "RSI Length", GroupName = "RSI", Order = 1)] public int RsiLength { get { return rsiLength; } set { rsiLength = Math.Max(1, value); } }
        [NinjaScriptProperty] [Display(Name = "RSI Overbought", GroupName = "RSI", Order = 2)] public int RsiOverbought { get { return rsiOverbought; } set { rsiOverbought = Math.Min(100, Math.Max(50, value)); } }
        [NinjaScriptProperty] [Display(Name = "RSI Oversold", GroupName = "RSI", Order = 3)] public int RsiOversold { get { return rsiOversold; } set { rsiOversold = Math.Min(50, Math.Max(0, value)); } }
        [NinjaScriptProperty] [Display(Name = "Show RSI Signals", GroupName = "RSI", Order = 4)] public bool ShowRsiSignals { get { return showRsiSignals; } set { showRsiSignals = value; } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "RSI Oversold Color", GroupName = "RSI", Order = 5)] public Brush RsiOversoldColor { get { return rsiOversoldColor; } set { rsiOversoldColor = value; } }
        [Browsable(false)] public string RsiOversoldColorSerialize { get { return Serialize.BrushToString(rsiOversoldColor); } set { rsiOversoldColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "RSI Overbought Color", GroupName = "RSI", Order = 6)] public Brush RsiOverboughtColor { get { return rsiOverboughtColor; } set { rsiOverboughtColor = value; } }
        [Browsable(false)] public string RsiOverboughtColorSerialize { get { return Serialize.BrushToString(rsiOverboughtColor); } set { rsiOverboughtColor = Serialize.StringToBrush(value); } }

        // MonarcaBand Options
        [NinjaScriptProperty] [Display(Name = "ColorLines", GroupName = "Options", Order = 1)] public ColorStyle ColorLines { get { return colorLines; } set { colorLines = value; } }
        [NinjaScriptProperty] [Display(Name = "DrawArrows", GroupName = "Options", Order = 2)] public bool DrawArrows { get { return drawArrows; } set { drawArrows = value; } }
        [NinjaScriptProperty] [Display(Name = "ArrowOffset", GroupName = "Options", Order = 3)] public int ArrowOffset { get { return arrowOffset; } set { arrowOffset = Math.Max(1, value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "ArrowUpColor", GroupName = "Options", Order = 4)] public Brush ArrowUpColor { get { return arrowUpColor; } set { arrowUpColor = value; } }
        [Browsable(false)] public string ArrowUpColorSerialize { get { return Serialize.BrushToString(arrowUpColor); } set { arrowUpColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "ArrowDownColor", GroupName = "Options", Order = 5)] public Brush ArrowDownColor { get { return arrowDownColor; } set { arrowDownColor = value; } }
        [Browsable(false)] public string ArrowDownColorSerialize { get { return Serialize.BrushToString(arrowDownColor); } set { arrowDownColor = Serialize.StringToBrush(value); } }

        [NinjaScriptProperty] [Display(Name = "ColorRegion", GroupName = "Options", Order = 6)] public bool ColorRegion { get { return colorRegion; } set { colorRegion = value; } }
        [NinjaScriptProperty] [Display(Name = "RegionOpacity", GroupName = "Options", Order = 7)] public int RegionOpacity { get { return regionOpacity; } set { regionOpacity = Math.Min(100, Math.Max(0, value)); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "RegionUpColor", GroupName = "Options", Order = 8)] public Brush RegionUpColor { get { return regionUpColor; } set { regionUpColor = value; } }
        [Browsable(false)] public string RegionUpColorSerialize { get { return Serialize.BrushToString(regionUpColor); } set { regionUpColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "RegionDownColor", GroupName = "Options", Order = 9)] public Brush RegionDownColor { get { return regionDownColor; } set { regionDownColor = value; } }
        [Browsable(false)] public string RegionDownColorSerialize { get { return Serialize.BrushToString(regionDownColor); } set { regionDownColor = Serialize.StringToBrush(value); } }

        [NinjaScriptProperty] [Display(Name = "SoundAlert", GroupName = "Options", Order = 10)] public bool SoundAlert { get { return soundAlert; } set { soundAlert = value; } }

        [NinjaScriptProperty]
        [Display(Name = "SoundFile", Description = "Sound file path for Crossover alert", GroupName = "Options", Order = 11)]
        [PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter = "WAV files (*.wav)|*.wav|All files (*.*)|*.*")]
        public string SoundFile { get { return soundFile; } set { soundFile = value; } }

        [NinjaScriptProperty] [Display(Name = "SoundAlertBand", GroupName = "Options", Order = 14)] public bool SoundAlertBand { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "SoundFileBand", Description = "Sound file path for Band entry alert", GroupName = "Options", Order = 15)]
        [PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter = "WAV files (*.wav)|*.wav|All files (*.*)|*.*")]
        public string SoundFileBand { get; set; }

        [NinjaScriptProperty] [Display(Name = "DrawDottedLine", GroupName = "Options", Order = 12)] public bool DrawDottedLine { get; set; }
        [NinjaScriptProperty] [Display(Name = "DottedLinePipsRange", GroupName = "Options", Order = 13)] public int DottedLinePipsRange { get; set; }

        // Custom Colors
        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "TriggerRisingColor", GroupName = "Custom Colors", Order = 1)] public Brush TriggerRisingColor { get { return triggerRisingColor; } set { triggerRisingColor = value; } }
        [Browsable(false)] public string TriggerRisingColorSerialize { get { return Serialize.BrushToString(triggerRisingColor); } set { triggerRisingColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "TriggerFallingColor", GroupName = "Custom Colors", Order = 2)] public Brush TriggerFallingColor { get { return triggerFallingColor; } set { triggerFallingColor = value; } }
        [Browsable(false)] public string TriggerFallingColorSerialize { get { return Serialize.BrushToString(triggerFallingColor); } set { triggerFallingColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "AverageRisingColor", GroupName = "Custom Colors", Order = 3)] public Brush AverageRisingColor { get { return averageRisingColor; } set { averageRisingColor = value; } }
        [Browsable(false)] public string AverageRisingColorSerialize { get { return Serialize.BrushToString(averageRisingColor); } set { averageRisingColor = Serialize.StringToBrush(value); } }

        [XmlIgnore()] [NinjaScriptProperty] [Display(Name = "AverageFallingColor", GroupName = "Custom Colors", Order = 4)] public Brush AverageFallingColor { get { return averageFallingColor; } set { averageFallingColor = value; } }
        [Browsable(false)] public string AverageColorSerialize { get { return Serialize.BrushToString(averageFallingColor); } set { averageFallingColor = Serialize.StringToBrush(value); } }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MonarcaBand[] cacheMonarcaBand;
		public MonarcaBand MonarcaBand(MAType triggerMAType, int triggerPeriod, MAType averageMAType, int averagePeriod, int eMAShortLength, int eMALongLength, bool showEMAs, bool showEMACrosses, Brush eMAShortColor, Brush eMALongColor, Brush eMACrossUpColor, Brush eMACrossDownColor, int rsiLength, int rsiOverbought, int rsiOversold, bool showRsiSignals, Brush rsiOversoldColor, Brush rsiOverboughtColor, ColorStyle colorLines, bool drawArrows, int arrowOffset, Brush arrowUpColor, Brush arrowDownColor, bool colorRegion, int regionOpacity, Brush regionUpColor, Brush regionDownColor, bool soundAlert, string soundFile, bool soundAlertBand, string soundFileBand, bool drawDottedLine, int dottedLinePipsRange, Brush triggerRisingColor, Brush triggerFallingColor, Brush averageRisingColor, Brush averageFallingColor)
		{
			return MonarcaBand(Input, triggerMAType, triggerPeriod, averageMAType, averagePeriod, eMAShortLength, eMALongLength, showEMAs, showEMACrosses, eMAShortColor, eMALongColor, eMACrossUpColor, eMACrossDownColor, rsiLength, rsiOverbought, rsiOversold, showRsiSignals, rsiOversoldColor, rsiOverboughtColor, colorLines, drawArrows, arrowOffset, arrowUpColor, arrowDownColor, colorRegion, regionOpacity, regionUpColor, regionDownColor, soundAlert, soundFile, soundAlertBand, soundFileBand, drawDottedLine, dottedLinePipsRange, triggerRisingColor, triggerFallingColor, averageRisingColor, averageFallingColor);
		}

		public MonarcaBand MonarcaBand(ISeries<double> input, MAType triggerMAType, int triggerPeriod, MAType averageMAType, int averagePeriod, int eMAShortLength, int eMALongLength, bool showEMAs, bool showEMACrosses, Brush eMAShortColor, Brush eMALongColor, Brush eMACrossUpColor, Brush eMACrossDownColor, int rsiLength, int rsiOverbought, int rsiOversold, bool showRsiSignals, Brush rsiOversoldColor, Brush rsiOverboughtColor, ColorStyle colorLines, bool drawArrows, int arrowOffset, Brush arrowUpColor, Brush arrowDownColor, bool colorRegion, int regionOpacity, Brush regionUpColor, Brush regionDownColor, bool soundAlert, string soundFile, bool soundAlertBand, string soundFileBand, bool drawDottedLine, int dottedLinePipsRange, Brush triggerRisingColor, Brush triggerFallingColor, Brush averageRisingColor, Brush averageFallingColor)
		{
			if (cacheMonarcaBand != null)
				for (int idx = 0; idx < cacheMonarcaBand.Length; idx++)
					if (cacheMonarcaBand[idx] != null && cacheMonarcaBand[idx].TriggerMAType == triggerMAType && cacheMonarcaBand[idx].TriggerPeriod == triggerPeriod && cacheMonarcaBand[idx].AverageMAType == averageMAType && cacheMonarcaBand[idx].AveragePeriod == averagePeriod && cacheMonarcaBand[idx].EMAShortLength == eMAShortLength && cacheMonarcaBand[idx].EMALongLength == eMALongLength && cacheMonarcaBand[idx].ShowEMAs == showEMAs && cacheMonarcaBand[idx].ShowEMACrosses == showEMACrosses && cacheMonarcaBand[idx].EMAShortColor == eMAShortColor && cacheMonarcaBand[idx].EMALongColor == eMALongColor && cacheMonarcaBand[idx].EMACrossUpColor == eMACrossUpColor && cacheMonarcaBand[idx].EMACrossDownColor == eMACrossDownColor && cacheMonarcaBand[idx].RsiLength == rsiLength && cacheMonarcaBand[idx].RsiOverbought == rsiOverbought && cacheMonarcaBand[idx].RsiOversold == rsiOversold && cacheMonarcaBand[idx].ShowRsiSignals == showRsiSignals && cacheMonarcaBand[idx].RsiOversoldColor == rsiOversoldColor && cacheMonarcaBand[idx].RsiOverboughtColor == rsiOverboughtColor && cacheMonarcaBand[idx].ColorLines == colorLines && cacheMonarcaBand[idx].DrawArrows == drawArrows && cacheMonarcaBand[idx].ArrowOffset == arrowOffset && cacheMonarcaBand[idx].ArrowUpColor == arrowUpColor && cacheMonarcaBand[idx].ArrowDownColor == arrowDownColor && cacheMonarcaBand[idx].ColorRegion == colorRegion && cacheMonarcaBand[idx].RegionOpacity == regionOpacity && cacheMonarcaBand[idx].RegionUpColor == regionUpColor && cacheMonarcaBand[idx].RegionDownColor == regionDownColor && cacheMonarcaBand[idx].SoundAlert == soundAlert && cacheMonarcaBand[idx].SoundFile == soundFile && cacheMonarcaBand[idx].SoundAlertBand == soundAlertBand && cacheMonarcaBand[idx].SoundFileBand == soundFileBand && cacheMonarcaBand[idx].DrawDottedLine == drawDottedLine && cacheMonarcaBand[idx].DottedLinePipsRange == dottedLinePipsRange && cacheMonarcaBand[idx].TriggerRisingColor == triggerRisingColor && cacheMonarcaBand[idx].TriggerFallingColor == triggerFallingColor && cacheMonarcaBand[idx].AverageRisingColor == averageRisingColor && cacheMonarcaBand[idx].AverageFallingColor == averageFallingColor && cacheMonarcaBand[idx].EqualsInput(input))
						return cacheMonarcaBand[idx];
			return CacheIndicator<MonarcaBand>(new MonarcaBand(){ TriggerMAType = triggerMAType, TriggerPeriod = triggerPeriod, AverageMAType = averageMAType, AveragePeriod = averagePeriod, EMAShortLength = eMAShortLength, EMALongLength = eMALongLength, ShowEMAs = showEMAs, ShowEMACrosses = showEMACrosses, EMAShortColor = eMAShortColor, EMALongColor = eMALongColor, EMACrossUpColor = eMACrossUpColor, EMACrossDownColor = eMACrossDownColor, RsiLength = rsiLength, RsiOverbought = rsiOverbought, RsiOversold = rsiOversold, ShowRsiSignals = showRsiSignals, RsiOversoldColor = rsiOversoldColor, RsiOverboughtColor = rsiOverboughtColor, ColorLines = colorLines, DrawArrows = drawArrows, ArrowOffset = arrowOffset, ArrowUpColor = arrowUpColor, ArrowDownColor = arrowDownColor, ColorRegion = colorRegion, RegionOpacity = regionOpacity, RegionUpColor = regionUpColor, RegionDownColor = regionDownColor, SoundAlert = soundAlert, SoundFile = soundFile, SoundAlertBand = soundAlertBand, SoundFileBand = soundFileBand, DrawDottedLine = drawDottedLine, DottedLinePipsRange = dottedLinePipsRange, TriggerRisingColor = triggerRisingColor, TriggerFallingColor = triggerFallingColor, AverageRisingColor = averageRisingColor, AverageFallingColor = averageFallingColor }, input, ref cacheMonarcaBand);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MonarcaBand MonarcaBand(MAType triggerMAType, int triggerPeriod, MAType averageMAType, int averagePeriod, int eMAShortLength, int eMALongLength, bool showEMAs, bool showEMACrosses, Brush eMAShortColor, Brush eMALongColor, Brush eMACrossUpColor, Brush eMACrossDownColor, int rsiLength, int rsiOverbought, int rsiOversold, bool showRsiSignals, Brush rsiOversoldColor, Brush rsiOverboughtColor, ColorStyle colorLines, bool drawArrows, int arrowOffset, Brush arrowUpColor, Brush arrowDownColor, bool colorRegion, int regionOpacity, Brush regionUpColor, Brush regionDownColor, bool soundAlert, string soundFile, bool soundAlertBand, string soundFileBand, bool drawDottedLine, int dottedLinePipsRange, Brush triggerRisingColor, Brush triggerFallingColor, Brush averageRisingColor, Brush averageFallingColor)
		{
			return indicator.MonarcaBand(Input, triggerMAType, triggerPeriod, averageMAType, averagePeriod, eMAShortLength, eMALongLength, showEMAs, showEMACrosses, eMAShortColor, eMALongColor, eMACrossUpColor, eMACrossDownColor, rsiLength, rsiOverbought, rsiOversold, showRsiSignals, rsiOversoldColor, rsiOverboughtColor, colorLines, drawArrows, arrowOffset, arrowUpColor, arrowDownColor, colorRegion, regionOpacity, regionUpColor, regionDownColor, soundAlert, soundFile, soundAlertBand, soundFileBand, drawDottedLine, dottedLinePipsRange, triggerRisingColor, triggerFallingColor, averageRisingColor, averageFallingColor);
		}

		public Indicators.MonarcaBand MonarcaBand(ISeries<double> input , MAType triggerMAType, int triggerPeriod, MAType averageMAType, int averagePeriod, int eMAShortLength, int eMALongLength, bool showEMAs, bool showEMACrosses, Brush eMAShortColor, Brush eMALongColor, Brush eMACrossUpColor, Brush eMACrossDownColor, int rsiLength, int rsiOverbought, int rsiOversold, bool showRsiSignals, Brush rsiOversoldColor, Brush rsiOverboughtColor, ColorStyle colorLines, bool drawArrows, int arrowOffset, Brush arrowUpColor, Brush arrowDownColor, bool colorRegion, int regionOpacity, Brush regionUpColor, Brush regionDownColor, bool soundAlert, string soundFile, bool soundAlertBand, string soundFileBand, bool drawDottedLine, int dottedLinePipsRange, Brush triggerRisingColor, Brush triggerFallingColor, Brush averageRisingColor, Brush averageFallingColor)
		{
			return indicator.MonarcaBand(input, triggerMAType, triggerPeriod, averageMAType, averagePeriod, eMAShortLength, eMALongLength, showEMAs, showEMACrosses, eMAShortColor, eMALongColor, eMACrossUpColor, eMACrossDownColor, rsiLength, rsiOverbought, rsiOversold, showRsiSignals, rsiOversoldColor, rsiOverboughtColor, colorLines, drawArrows, arrowOffset, arrowUpColor, arrowDownColor, colorRegion, regionOpacity, regionUpColor, regionDownColor, soundAlert, soundFile, soundAlertBand, soundFileBand, drawDottedLine, dottedLinePipsRange, triggerRisingColor, triggerFallingColor, averageRisingColor, averageFallingColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MonarcaBand MonarcaBand(MAType triggerMAType, int triggerPeriod, MAType averageMAType, int averagePeriod, int eMAShortLength, int eMALongLength, bool showEMAs, bool showEMACrosses, Brush eMAShortColor, Brush eMALongColor, Brush eMACrossUpColor, Brush eMACrossDownColor, int rsiLength, int rsiOverbought, int rsiOversold, bool showRsiSignals, Brush rsiOversoldColor, Brush rsiOverboughtColor, ColorStyle colorLines, bool drawArrows, int arrowOffset, Brush arrowUpColor, Brush arrowDownColor, bool colorRegion, int regionOpacity, Brush regionUpColor, Brush regionDownColor, bool soundAlert, string soundFile, bool soundAlertBand, string soundFileBand, bool drawDottedLine, int dottedLinePipsRange, Brush triggerRisingColor, Brush triggerFallingColor, Brush averageRisingColor, Brush averageFallingColor)
		{
			return indicator.MonarcaBand(Input, triggerMAType, triggerPeriod, averageMAType, averagePeriod, eMAShortLength, eMALongLength, showEMAs, showEMACrosses, eMAShortColor, eMALongColor, eMACrossUpColor, eMACrossDownColor, rsiLength, rsiOverbought, rsiOversold, showRsiSignals, rsiOversoldColor, rsiOverboughtColor, colorLines, drawArrows, arrowOffset, arrowUpColor, arrowDownColor, colorRegion, regionOpacity, regionUpColor, regionDownColor, soundAlert, soundFile, soundAlertBand, soundFileBand, drawDottedLine, dottedLinePipsRange, triggerRisingColor, triggerFallingColor, averageRisingColor, averageFallingColor);
		}

		public Indicators.MonarcaBand MonarcaBand(ISeries<double> input , MAType triggerMAType, int triggerPeriod, MAType averageMAType, int averagePeriod, int eMAShortLength, int eMALongLength, bool showEMAs, bool showEMACrosses, Brush eMAShortColor, Brush eMALongColor, Brush eMACrossUpColor, Brush eMACrossDownColor, int rsiLength, int rsiOverbought, int rsiOversold, bool showRsiSignals, Brush rsiOversoldColor, Brush rsiOverboughtColor, ColorStyle colorLines, bool drawArrows, int arrowOffset, Brush arrowUpColor, Brush arrowDownColor, bool colorRegion, int regionOpacity, Brush regionUpColor, Brush regionDownColor, bool soundAlert, string soundFile, bool soundAlertBand, string soundFileBand, bool drawDottedLine, int dottedLinePipsRange, Brush triggerRisingColor, Brush triggerFallingColor, Brush averageRisingColor, Brush averageFallingColor)
		{
			return indicator.MonarcaBand(input, triggerMAType, triggerPeriod, averageMAType, averagePeriod, eMAShortLength, eMALongLength, showEMAs, showEMACrosses, eMAShortColor, eMALongColor, eMACrossUpColor, eMACrossDownColor, rsiLength, rsiOverbought, rsiOversold, showRsiSignals, rsiOversoldColor, rsiOverboughtColor, colorLines, drawArrows, arrowOffset, arrowUpColor, arrowDownColor, colorRegion, regionOpacity, regionUpColor, regionDownColor, soundAlert, soundFile, soundAlertBand, soundFileBand, drawDottedLine, dottedLinePipsRange, triggerRisingColor, triggerFallingColor, averageRisingColor, averageFallingColor);
		}
	}
}

#endregion
